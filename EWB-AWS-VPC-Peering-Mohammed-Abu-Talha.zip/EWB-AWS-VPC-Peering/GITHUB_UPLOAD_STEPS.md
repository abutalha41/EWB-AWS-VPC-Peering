# Upload the project to GitHub

1. Download and extract `EWB-AWS-VPC-Peering-GitHub-Package.zip`.
2. Open https://github.com/new and create a repository named `EWB-AWS-VPC-Peering`.
3. Add a short description such as: `AWS VPC Peering lab with private EC2 instances, route tables, security groups and bastion SSH access.`
4. Choose Public only if your instructor needs open access. Otherwise choose Private and invite them.
5. If you are uploading the prepared files, do not create a second README during repository setup.
6. In the repository, select **Add file → Upload files** and upload the contents of the extracted folder.
7. Commit with a message such as `Add VPC Peering report and test evidence`.
8. Open the repository and check that the README, PDF report, architecture diagram and screenshots appear correctly.
9. Never upload your `.pem` key, AWS credentials, passwords, tokens or local `.ssh/config`.

Repository URL format: `https://github.com/YOUR-USERNAME/EWB-AWS-VPC-Peering`
